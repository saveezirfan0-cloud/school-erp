// scripts/migrate-firestore-to-supabase.mjs
//
// One-time data migration: reads every Firestore collection and
// writes the rows into the matching Supabase table.
//
// Run locally (NOT in the browser):
//   1. npm i firebase-admin @supabase/supabase-js
//   2. Download a Firebase service-account JSON from
//      Firebase console → Project settings → Service accounts →
//      "Generate new private key". Save as ./serviceAccount.json
//   3. Set env vars and run:
//        SUPABASE_URL=https://xxxx.supabase.co \
//        SUPABASE_SERVICE_ROLE_KEY=eyJ... \
//        node scripts/migrate-firestore-to-supabase.mjs
//
// Uses the SERVICE ROLE key so it bypasses RLS. Never ship that key
// to the browser.

import admin from "firebase-admin";
import { createClient } from "@supabase/supabase-js";
import { readFileSync } from "node:fs";

const svc = JSON.parse(readFileSync("./serviceAccount.json", "utf8"));
admin.initializeApp({ credential: admin.credential.cert(svc) });
const fs = admin.firestore();

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY,
  { auth: { persistSession: false } }
);

// Firestore collection -> Supabase table
const MAP = {
  users: "users",
  branches: "branches",
  students: "students",
  employees: "employees",
  invoices: "invoices",
  expenses: "expenses",
  payments: "payments",
  payslips: "payslips",
  accounts: "accounts",
  journals: "journals",
  customRoles: "custom_roles",
  reminderLogs: "reminder_logs",
  auditLog: "audit_log",
};

// Real columns per table (mirror schema.sql). Unknown keys -> extra jsonb.
const COLUMNS = {
  users: ["id", "uid", "name", "email", "role", "branch_id", "pin"],
  branches: ["id", "name", "address", "phone"],
  students: ["id", "name", "student_id", "grade", "parent_name", "parent_phone", "email", "branch_id", "monthly_fee", "address", "dob", "recurring_fee"],
  employees: ["id", "name", "branch_id"],
  invoices: ["id", "student_id", "branch_id", "amount", "status", "due_date", "date"],
  expenses: ["id", "description", "category", "amount", "date", "branch_id"],
  payments: ["id", "type", "account", "description", "category", "amount", "date", "reference", "branch_id"],
  payslips: ["id", "employee_id", "branch_id", "amount", "month", "date"],
  accounts: ["id", "code", "name", "type", "sub_type"],
  journals: ["id", "date", "reference", "description", "debit_account", "credit_account", "amount", "notes"],
  custom_roles: ["id", "permissions"],
  reminder_logs: ["id", "student_id", "phone", "message", "status", "date", "timestamp"],
  audit_log: ["id", "user", "action", "module", "details", "timestamp"],
};

const toSnake = (s) => s.replace(/[A-Z]/g, (m) => "_" + m.toLowerCase());

// Firestore Timestamp -> ISO string
function fixVal(v) {
  if (v && typeof v === "object" && typeof v.toDate === "function") {
    return v.toDate().toISOString();
  }
  return v;
}

function isUuid(s) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(s);
}

function encode(table, id, data) {
  const cols = COLUMNS[table];
  const row = {};
  const extra = {};

  // id: tables with text PK (custom_roles) keep the doc id;
  // users keep the Firebase uid (it must match the new auth user — see notes);
  // uuid-PK tables only keep id if it's already a uuid, else let Postgres assign.
  if (table === "custom_roles") row.id = id;
  else if (table === "users") row.id = id; // see migration notes re: auth uids
  else if (isUuid(id)) row.id = id;

  for (const [k, raw] of Object.entries(data || {})) {
    const v = fixVal(raw);
    const snake = toSnake(k);
    if (snake === "id") continue;
    if (cols.includes(snake)) row[snake] = v;
    else extra[k] = v;
  }
  if (Object.keys(extra).length) row.extra = extra;
  return row;
}

async function migrateCollection(coll, table) {
  const snap = await fs.collection(coll).get();
  if (snap.empty) {
    console.log(`· ${coll}: empty, skipped`);
    return;
  }
  const rows = snap.docs.map((d) => encode(table, d.id, d.data()));

  // chunk to stay under payload limits
  const size = 500;
  for (let i = 0; i < rows.length; i += size) {
    const chunk = rows.slice(i, i + size);
    const { error } = await supabase.from(table).upsert(chunk, { onConflict: "id" });
    if (error) {
      console.error(`✗ ${coll} chunk ${i}:`, error.message);
      throw error;
    }
  }
  console.log(`✓ ${coll} → ${table}: ${rows.length} rows`);
}

async function main() {
  for (const [coll, table] of Object.entries(MAP)) {
    try {
      await migrateCollection(coll, table);
    } catch (e) {
      console.error(`Failed on ${coll}:`, e.message);
    }
  }
  console.log("\nDone.");
  process.exit(0);
}

main();
